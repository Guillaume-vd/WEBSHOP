  <div class="container body-content column-right">
		<h1> Accueil </h1>
		<hr />
		<footer>
		  <?php
			echo("<p>".date("Y")." - ISIWEB4Shop</p>");
		  ?>
		</footer>
  </div>
  </body>
</html>
