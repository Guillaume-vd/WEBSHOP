<div class="columnleft">
	<nav class="vertical-menu">
		<a class="accueil active" href="index.php?page=Home">Accueil</a></li>
		  <?php
				require_once(PATH_CONTROLLERS.'categorie.php');
			  foreach ($cat as $value) {
				echo "<a href='Index.php?page=productslist&category=".$value."'>Nos $value</a>";
			}
		 ?>
	</nav>
</div>
