function modif_qty(int){
  var nbprod = document.getElementById("nbprod");
  var int_prod = parseInt(nbprod.value);
  if (int_prod==0 && int==-1){
    int=0;
  }
  int_prod=int_prod+int;
  nbprod.value=int_prod;
}
