<div class="container body-content column-right">
      <?php
      echo"<table><tr>";
      foreach ($prodname as $value) {
        $price=DialogueBD::getPrice($value);
        $img_name=DialogueBD::getImage($value);
        $desc=DialogueBD::getDesc($value);
        echo"<tr>";
        echo "<td class='tdprod'><a href='Index.php?page=products&product=".$value."'>$value </td>";
        echo "<td class='tdprod'><img src='Content/productimages/$img_name' alt='$img_name'></a></td>";
        echo "<td class='tdprod'>Prix : $price €</td>";
        echo "<td class='tdprod'> Description : $desc<br/>";
        echo "</td></tr>";
      }
      echo("</table>")
      ?>
      <hr />
      <footer>
  <?php
    echo("<p>".date("Y")." - ISIWEB4Shop</p>");
  ?>
      </footer>
</div>
</body>
</html>
