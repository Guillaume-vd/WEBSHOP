<div class="caisse">
      <h1>Caisse</h1>
      <?php
      echo "<p> Entrez votre adresse de livraison </p>";
      echo "<input class='nbprod' type='text' name='add' id='add' />";
      echo "<input type='subimit' class='ajouter_add' value='Valider votre adresse' />";
      echo "<input type='button' class='btpaiement' value='Paiement via Paypal'>";
      echo "<input type='button' class='btpaiement' value='Paiement par chèque'>";
      echo "<input type='button' class='btfinal' value='Finaliser la commande'>";
       ?>
</div>
</body>
</html>
