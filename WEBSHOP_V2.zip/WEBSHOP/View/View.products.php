		<div class="container body-content column-right">
			<div class="container body-content column-right">
				<?php
					$product=$_GET['product'];
					echo"<form action='index.php?page=panier&product=$product' method='post'>";
					$img_name=DialogueBD::getImage($product);
					echo "<h1> $product</h1>";
					echo "<input type='hidden' name='prodname' value='$product' />";
					echo "<p><img class='imgprod' src='Content/productimages/$img_name' alt='$img_name'</p><br/>";
					$desc=DialogueBD::getDesc($product);
					echo "Description : $desc";
					$prix=DialogueBD::getPrice($value);

					?>

				<hr />

				<input type='button' value='-' onclick='modif_qty(-1)'/>
				<input class='nbprod' type='text' name='nbprod' id='nbprod' value='1' onselect='bloque_champ(this);' onFocus='bloque_champ(this);'/>
				<input type='button' value='+' onclick='modif_qty(+1)'/>
				<br/>
				<input type="submit" name="adding" value ="Ajouter au panier"/>
				</form>


				<hr />

            <footer>
              <?php
                echo("<p>".date("Y")." - ISIWEB4Shop</p>");
              ?>
            </footer>
		</div>
	</body>
</html>
