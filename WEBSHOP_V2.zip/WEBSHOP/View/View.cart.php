<?php
  require_once('./Controller/Model.Cart.php');
  $items=returnItemsCart();
  $cart=returnCart();
 ?>
<div class="panier">
      <h1>Panier</h1>
      <?php
      $prixtotal=0;
      foreach($items as $value){
        $prixitems=DialogueBD::getPrice($value);
        $quantity=$cart[$value];
        $prix=$quantity*$prixitems;
        echo"<tr><td> $value <br/></td>";
        echo"<td> Quantité : $quantity<br/></td>";
        echo"<td> $prixitems €</td></tr>";
        echo"<form action='index.php?page=delete&?prod=$value' method='post'>";
        echo "<input type='hidden' name='prodname' value='$value' />";
        echo"<input type='submit' value='Supprimer'/></form>";
        $prixtotal=$prixtotal+$prix;
      }
      echo " $prixtotal €";
      echo"<a href='index.php?page=caisse&prix=$prixtotal'> Aller à la caisse</a>";
       ?>
</div>
