<?php
  require_once('Model.Cart.php');
  dropCart();
  $_SESSION['role'] = 'invite';
  header("Location: index.php");
?>
