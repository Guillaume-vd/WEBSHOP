<?php
require_once(PATH_CONTROLLERS."DialogueBD.php");
$cat=DialogueBD::getCat();

?>
