<?php
  require_once('Model.cart.php');
  dropProduct($_POST['prodname']);
  header("Location: ./index.php?page=home");
  exit();
 ?>
