<?php

require_once(PATH_VIEWS."bar.php");
require_once(PATH_VIEWS."Categorie.php");
require_once(PATH_VIEWS."cart.php");
require_once(PATH_VIEWS."Accueil.php");

?>
