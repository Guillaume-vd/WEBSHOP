<?php
  require_once(PATH_CONTROLLERS."ConnexionBD.php") ;

  class DialogueBD {

    function getidCat(){
      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT id FROM categories ORDER BY id";
        $sth = $conn->query($sql);
        $tabidCat=array();
        while($idcats = $sth->fetch()){
          $tabidCat[]=$idcats['id'];
        }
        return $tabidCat;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getCat(){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT name FROM categories ORDER BY id";
        $sth = $conn->query($sql);
        $tabCat=array();
        while($cats = $sth->fetch()){
          $tabCat[]=$cats['name'];
        }
        return $tabCat;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getProd($cat){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT name FROM products WHERE cat_name = ? ORDER BY id";
        $sth = $conn->prepare($sql);
        $sth->execute(array($cat));
        $tabProd=array();
        while($prod = $sth->fetch()){
          $tabProd[]=$prod['name'];
        }
        return $tabProd;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getPrice($prod){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT price FROM products WHERE name= ? ORDER BY id";
        $sth = $conn->prepare($sql);
        $sth->execute(array($prod));
        $price = $sth->fetch();
        $prix=$price['price'];

        return $prix;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getImage($prod){
      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT image FROM products WHERE name= ? ORDER BY id";
        $sth = $conn->prepare($sql);
        $sth->execute(array($prod));
        $img = $sth->fetch();
        $img_name=$img['image'];

        return $img_name;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getDesc($prod){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT description FROM products WHERE name= ? ORDER BY id";
        $sth = $conn->prepare($sql);
        $sth->execute(array($prod));
        $desc = $sth->fetch();
        $description=$desc['description'];

        return $description;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    
  }
?>
