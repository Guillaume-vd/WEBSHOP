<?php
  require_once("Controller.ConnexionBD.php") ;

function addToCart($prod,$qty){
  $conn = Connexion::getConnexion();
  $sql = "INSERT INTO orderitems (product_name, quantity) VALUES (? , ?)";
  $sth = $conn->prepare($sql);
  $sth->execute(array($prod,$qty));
}
function returnCart(){
  $conn = Connexion::getConnexion();
  $sql = "SELECT product_name,quantity FROM orderitems ";
  $sth = $conn->prepare($sql);
  $sth->execute();
  $tabCart=array();
  while($prods = $sth->fetch()){
    $key=$prods['product_name'];
    $tabCart[$key]=$prods['quantity'];
  }
  return $tabCart;
}
function returnItemsCart(){
  $conn = Connexion::getConnexion();
  $sql = "SELECT product_name FROM orderitems ";
  $sth = $conn->prepare($sql);
  $sth->execute();
  $tabCart=array();
  while($prods = $sth->fetch()){
    $tabCart[]=$prods['product_name'];
  }
  return $tabCart;
}
function dropCart(){
  $conn = Connexion::getConnexion();
  $sql = "DELETE FROM orderitems";
  $sth = $conn->query($sql);
}

function dropProduct($prod){
  $conn = Connexion::getConnexion();
  $sql = "DELETE FROM orderitems WHERE product_name=?";
  $sth = $conn->prepare($sql);
  $sth->execute(array($prod));
}
?>
