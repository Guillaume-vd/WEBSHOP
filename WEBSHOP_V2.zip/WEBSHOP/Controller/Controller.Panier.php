<?php
	require_once('Model.Cart.php');
	$prodname=$_POST['prodname'];
	$quantity=$_POST['nbprod'];
	addToCart($prodname,$quantity);
	$cart=returnCart();
	$items=returnItemsCart();
	header("Location: ./index.php?page=home");
	exit();
?>
