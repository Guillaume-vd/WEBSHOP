<?php
  session_start();

  //Dossiers racines du site
  define('PATH_CONTROLLERS', './Controller/Controller.');
  define('PATH_VIEWS', './View/View.');
  define('PATH_MODELS', './Models/Model.');


  //Sous-Dossiers
  define('PATH_IMAGES', './Content/productimages/');
  define('PATH_SCRIPTS', './Content/js/');
  define('PATH_CSS', './Content/css/');



?>
