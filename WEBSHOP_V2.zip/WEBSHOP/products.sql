-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  Dim 26 jan. 2020 à 02:42
-- Version du serveur :  10.4.8-MariaDB
-- Version de PHP :  7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `isiweb4shop`
--

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `cat_id` tinyint(4) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(30) NOT NULL,
  `price` float NOT NULL,
  `cat_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`id`, `cat_id`, `name`, `description`, `image`, `price`, `cat_name`) VALUES
(1, 1, 'Saveur Impériale', 'Sachet de thé de qualité supérieure.200 sachets par boite', 'theImperial.jpg', 4.99, 'boissons'),
(2, 1, 'Jus d’Orange de Floride', 'Bouteille d’un litre.\r\nSans conservateur, ni arômes artificiels.', 'bestorange-juice.jpg', 0.9, 'boissons'),
(3, 1, 'Dosette de café', 'Dosette de café issu du commerce équitable.', 'dosetteCafe.jpg', 2.49, 'boissons'),
(4, 2, 'Biscuit au raisin', 'Biscuits au raisin bio.', 'biscuitRaisin.jpg', 1, 'biscuits'),
(5, 3, 'Abricots secs', 'Abricots secs bio issu de producteurs locaux. 200g', 'abricots.jpg', 2, 'fruitssecs'),
(6, 3, 'Amande', 'Amande bio provenant de producteurs locaux. 200g', 'amande.jpg', 3.99, 'fruitssecs'),
(7, 1, 'Jus de Pomme', 'Bouteille d\'un litre', 'juspomme.jpg', 0.79, 'boissons'),
(8, 2, 'Biscuit de Noël', 'Boîte de 250g.', 'biscuitNoel.jpg', 4.49, 'biscuits'),
(9, 2, 'Cookie', 'Boîte de 10 cookie.\r\nPoids 150g.', 'cookie.jpg', 0.99, 'biscuits'),
(10, 2, 'Assortiments de biscuits sec', 'Boîte de 300g.\r\n3 types de biscuits :\r\n-cookie\r\n-biscuit au raisin\r\n-biscuit de Noël', 'assortimentBiscuitsSec.jpg', 4.99, 'biscuits'),
(11, 3, 'Raisins secs bio', 'Raisins secs bio provenant d\'agriculteur du Rhône-Alpes.\r\n100g', 'raisinsecs.jpg', 2.59, 'fruitssecs'),
(12, 1, 'Lait écrémé', 'Lait bio provenant de vaches élevées dans les Alpes.', 'lait.jpg', 1.5, 'boissons');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
