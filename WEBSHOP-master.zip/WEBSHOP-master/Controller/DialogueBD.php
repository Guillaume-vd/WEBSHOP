<?php
  require_once "Connexion.php" ;

    function getidCat(){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT id FROM categories ORDER BY id";
        $sth = $conn->query($sql);
        $tabidCat=array();
        while($idcats = $sth->fetch()){
          $tabidCat[]=$idcats['id'];
        }
        return $tabidCat;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getCat(){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT name FROM categories ORDER BY id";
        $sth = $conn->query($sql);
        $tabCat=array();
        while($cats = $sth->fetch()){
          $tabCat[]=$cats['name'];
        }
        return $tabCat;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getidProd($catid){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT id FROM products WHERE cat_id=$catid ORDER BY id";
        $sth = $conn->query($sql);
        $tabidProd=array($catid);
        while($idprod = $sth->fetch()){
          $tabidProd[]=$idprod['id'];
        }
        return $tabidProd;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getProd($catid){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT name FROM products WHERE cat_id=$catid ORDER BY id";
        $sth = $conn->query($sql);
        $tabProd=array();
        while($prod = $sth->fetch()){
          $tabProd[]=$prod['name'];
        }
        return $tabProd;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getPrice($catid){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT price FROM products WHERE cat_id=$catid ORDER BY id";
        $sth = $conn->query($sql);
        $tabprice=array();
        while($price = $sth->fetch()){
          $tabprice[]=$price['price'];
        }
        return $tabprice;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getImage($catid){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT image FROM products WHERE cat_id=$catid ORDER BY id";
        $sth = $conn->query($sql);
        $tabiamge=array();
        while($image = $sth->fetch()){
          $tabimage[]=$image['image'];
        }
        return $tabimage;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }

    function getDesc($product){

      try
      {
        $conn = Connexion::getConnexion();
        $sql = "SELECT description FROM produits WHERE id=$product ORDER BY id";
        $sth = $conn->query($sql);
        $tabdesc=array();
        while($desc = $sth->fetch()){
          $tabdesc[]=$desc['description'];
        }
        return $tabdesc;
      }
      catch (PDOException $e)
      {
        $erreur = $e->getMessage();
      }
    }


?>
