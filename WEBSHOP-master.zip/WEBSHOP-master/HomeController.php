<?php
require 'Controller/DialogueBD.php';
$catid=getidCat();
$catname=getCat();
$category='Boissons';
$cat=array('Boissons','Biscuits','Fruits secs');
$logged=true;
$nom="Tanguy";
$prodid=getidProd($category);
$prodname=getProd($category);
$imaage=getImage($category);
$prixxx=getPrice($category);



?>
