<?php
require_once 'Controller/DialogueBD.php';
$catid=getidCat();
$catname=getCat();
$category=1;

$logged=true;
$login="Tanguy";
?>
