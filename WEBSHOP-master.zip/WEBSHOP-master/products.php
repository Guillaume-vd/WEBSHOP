<?php
require_once 'HomeController.php';
require_once 'ProductslistController.php';
?>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html"; charset="utf-8"/>
    <link href="Content\css\bootstrap.css" rel="stylesheet" />
    <link href="Content\css\design.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="product.js">
    </script>
    <title>ISIWEB4SHOP</title>
  </head>
  <body>
      <div class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="navbar-header">
                  <a class='navbar-brand'href="accueil.php"> ISIWEB4Shop </a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <?php
                if($connecte){
                  echo("<li><p class='navbar-text'> <span class='glyphicon glyphicon-user'></span> $nom </p></li>");
                  echo("<li><p class='navbar-text'> <span class='glyphicon glyphicon-log-in'> </span> <a href='login.php'> Déconnexion </a> </p></li>");
                }
                else{
                  echo("<li><p class='navbar-text'> <span class='glyphicon glyphicon-user'> </span> <a href='signin.php'> S'inscrire </a> </p></li>");
                  echo("<li><p class='navbar-text'> <span class='glyphicon glyphicon-log-in'> </span> <a href='login.php'> Se connecter </a> </p></li>");
                }
                ?>
                  <li><p class="navbar-text"> <span class="glyphicon glyphicon-shopping-cart"> </span> <a href="cart.php"> Panier </a></p></li> <!--Metttre le nombre d'article en badge pour le panier-->

              </ul>
          </div>
      </div>
      <div class="columnleft">
        <nav class="vertical-menu">
            <a class="accueil" href="accueil.php">Accueil</a></li>
              <?php
                  foreach ($cat as $value) {
                  echo "<a href='productslist.php?category=$value'>Nos $value</a>";

                }
             ?>
        </nav>
      </div>
      <div class="container body-content column-right">
            <?php
              echo "<h1> zfzafzaf </h1>";
              echo "<p><img class='imgprod' src='Content/productimages/$img_name' alt='$img_name'</p><hr/>";
              show_desc($img_name);
            ?>
              <hr />
              <input type="button" value="-" onclick="clic_moins()"/>
              <input class="nbprod" type="text" name="nbprod" id="nbprod" value="0" onselect="bloque_champ(this);" onFocus="bloque_champ(this);"/>
              <input type="button" value="+" onclick="clic_plus()"/>
              <input type="submit" name="adding" value ="Ajouter au panier"/>
            <hr />
              <?php
                getPrixNb();
                print_r($catid);
                print_r($catname);
                print_r($prodid);
                print_r($prodname);
                print_r($imaage);
                print_r($prixxx);
               ?>

            <hr />
            <footer>
              <?php
                echo("<p>".date("Y")." - ISIWEB4Shop</p>");
              ?>
            </footer>
      </div>
  </body>
</html>
