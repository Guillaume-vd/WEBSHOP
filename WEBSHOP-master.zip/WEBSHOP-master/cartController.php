<?php
require 'product.php';

  $choosen_prod=getCart();
  

  function sumPrice($id){
    return $prix[$id]*$quantity;
  }

 function totalprice(){
   $sum=0;
   foreach($choosen_prod as $prod){
     $id_prod=get_idprod($prod);
     $price=$prix[$id]*$quantity;
     $sum=$sum+$price;
   }
   return $sum;
 }
