<?php
$aa="aaaaaaaaaa";
$connecte=true;
$nom="Tanguy";
$cat=array ('Boissons', 'Biscuits','Fruits secs');

?>
