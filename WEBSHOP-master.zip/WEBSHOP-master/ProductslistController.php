<?php
require_once 'Controller/DialogueBD.php';
require 'HomeController.php';
$quantity=array();


$category=$_GET['category'];

function totalPrice($qty,$price){
  $totalprice=$qty*$price;
}

function getQuantity($id){
  $quantity[$id]=$_POST['nbprod'];
}

$prodname=getProd($category);
 ?>
