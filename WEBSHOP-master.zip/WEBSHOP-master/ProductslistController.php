<?php
require_once 'Controller/DialogueBD.php';
$quantity=array();

$catid=getidCat();
$catname=getCat();
$category=$_GET["category"];

function getQuantity($id){
  $quantity[$id]=$_POST['nbprod'];
}

$prodid=getidProd($category);
$prodname=getProd($category);
$imaage=getImage($category);
$prixxx=getPrice($category);
 ?>
